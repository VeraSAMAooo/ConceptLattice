// pages/excl/excl.js
Page({

  /**
   * 页面的初始数据
   */

  data: {
    data1:'',
    data2:'',
    data3:''
  },

  next:function(param)
  {
    var _this = this
  wx.request({
   url: 'http://localhost:8000/getd',
   data: {
    a:_this.data.data1,
    b:_this.data.data2,
    c:_this.data.data3,
  },
   method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
   header: {apikey:'a37c01591e47494fe320137dbc0fd423'}, // 设置请求的 header
   success: function(res){
    // success
    console.log(res)
    wx.navigateTo({
      url: "/pages/bool/bool",
    })

   },
   
fail: function() {
    // fail
   },
   complete: function() {
    // complete
   }
  })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  get1:function(e){
    console.log(e)
   this.setData({
     data1: e.detail.value
   })

 },
 get3:function(e){
   console.log(e)

   this.setData({
     data3: e.detail.value
   })

 },
 get2:function(e){
   console.log(e)

   this.setData({
     data2: e.detail.value
   })

 },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})